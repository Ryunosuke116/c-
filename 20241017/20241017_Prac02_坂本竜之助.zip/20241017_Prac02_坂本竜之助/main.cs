﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c_._20241017._20241017_Prac02_坂本竜之助
{


    internal class _main
    {
       static void Main(string[] args)
        {
            //インスタンス化
            GameController gameController = new GameController();
            gameController.Game();
        }
    }
}
